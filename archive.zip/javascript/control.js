Sim.Round = {
	getCurrent: function(){
		return Globals.Sim.round ;
	},
	setCurrent: function(round){
		Globals.Sim.round = parseInt(round);
	},
	flagReadyToAdvance: function(){
		var vals = {
			'D_All Round Decisions Made[1]': 1,
			'D_All Round Decisions Made[2]': 1,
			'D_All Round Decisions Made[3]': 1,
			'D_All Round Decisions Made[4]': 1,
			'D_All Round Decisions Made[5]': 1,
			'D_All Round Decisions Made[6]': 1
		}
		Sim.setDecisions(vals);
	},
	advanceTo: function(round, callback){
		this.setCurrent(round);
		var step = parseInt(round) + 1;
		F.API.Run.stepTo(step, callback, {target: "include/timer.txt"});
	},
	advanceToNext: function(callback){
		var round = this.getCurrent() + 1;
		this.setCurrent(round);
		var step = parseInt(round) + 1;
		F.API.Run.stepTo(step, callback);
	}
}

Sim.Stage = {
	getCurrent: function(){
		return Globals.Sim.stage;
	},
	setCurrent: function(stage){
		Globals.Sim.stage = parseInt(stage);
	},
	advanceTo: function(stage, callback){
		//this.setCurrent(stage);
		//console.log("advancing to stage " + stage);
		//var qs = "D_Decisions Stage Per Player[" + Globals.User.departmentID +"]=" + stage;

		var vals = {};
		for(var i=1; i<7; i++){
			vals['D_Decisions Stage Per Player['+i+']'] = stage
		}

		Sim.setDecisions(vals, callback);
	}
}

var dbug = {
	_save : function(decn, val){
		val || (val = 1);
	},
	resetTimer: function(){

		F.API.Data.remove('timer');
	},

	openSim: function(){
		Sim.setDecisions("D_DecisionsOn=1",function(){
			nav.goToPage('usr_settings','forceLoad=true');
		});
	},
	advanceAll: function(callback){
		var vals = {
			'D_All Round Decisions Made[1]': 1,
			'D_All Round Decisions Made[2]': 1,
			'D_All Round Decisions Made[3]': 1,
			'D_All Round Decisions Made[4]': 1,
			'D_All Round Decisions Made[5]': 1,
			'D_All Round Decisions Made[6]': 1
		}
		Sim.setDecisions(vals);
		if(callback) callback();
	},
	advanceStageAll: function(callback){
		var vals = {
			'D_All Stage Decisions Made[1]': 1,
			'D_All Stage Decisions Made[2]': 1,
			'D_All Stage Decisions Made[3]': 1,
			'D_All Stage Decisions Made[4]': 1,
			'D_All Stage Decisions Made[5]': 1,
			'D_All Stage Decisions Made[6]': 1
		}
		Sim.setDecisions(vals);
		if(callback) callback();
	},
	setStage: function(stage){
		var vals = {};
		for(var i=1; i<7; i++){
			vals['D_Decisions Stage Per Player['+i+']'] = stage
		}
		Sim.setDecisions(vals)
	},
	assignRoles: function(forceConflict){
		var vals = {};
		for(var i=1; i<7; i++){
			vals['D_PlayerRole['+i+']'] = i
		}
		if (forceConflict === true) {
			vals['D_PlayerRole[1]'] = vals['D_PlayerRole[2]'] = 1;
		}
		Sim.setDecisions(vals)
	},

	makeConsensus : function(){
		var vals = {
			'D_Consensus Decision[1]': 1,
			'D_Consensus Decision[2]': 1,
			'D_Consensus Decision[3]': 1,
			'D_Consensus Decision[4]': 1,
			'D_Consensus Decision[5]': 1,
			'D_Consensus Decision[6]': 1
		}
		Sim.setDecisions(vals);
	},

	selectMarket: function(val){
		var vals = {};
		for(var i=1; i<7; i++){
			vals['D_Market to Enter['+i+']'] = val;
		}
		Sim.setDecisions(vals)
	},
	nominate: function(val){
		val || (val = 1);
		var vals = {};
		for(var i=1; i<7; i++){
			vals['D_CEO Nomination['+i+']'] = val
		}
		Sim.setDecisions(vals);
	},

	setAsCEO: function(val){
		val || (val = 1);
		var vals = {};
		for(var i=1; i<7; i++){
			vals['D_CEO Selection['+i+']'] = val
		}
		Sim.setDecisions(vals);
	},


	setNumberOfPlayers: function(num){
		num = num || 6;
		var vals = {
			'D_NumberOfPlayers': num
		}
		Sim.setDecisions(vals);
	}
}