function testJScript(){
	if (document.getElementById)    {
		$('#jsMessage').css({display: "none"});
		return true;
	}
	return false;
}

function testFlash(){
	var version = swfobject.getFlashPlayerVersion();
	if (version['major'] < 10)   {
		$('#flashMessage').css({display: "block"});
		$("#formItself").remove();
		return false;
	}
	return true;
}

function testBrowser(){
	if($.browser.opera || $.browser.msie || $.browser.safari)    {
		$('#browserMessage').css({display: "block"});
		return true;
	}
	return true;
}

function testCookies(){
	if(document.cookie != "")
	return true;

	$('#cookiesMessage').css({display: "block"});
	return false;
}

document.domain = "forio.com";
var Login = (function(){
	var NO_OF_SERVERS = 4;
	var PREFIX  = "wharton";

	//Destination server; aggregated by team
	var getServerForTeam = function(team){
		var targetServer =  (parseInt(team) % NO_OF_SERVERS) + 1;
		return PREFIX + targetServer;
	}

	//Setup api utils manually as we can't get stuff from url anymore
//	F.APIUtils.domain = function(){
//		//Set random domain for future requests
//		var sNo =  Math.ceil(Math.random()* NO_OF_SERVERS);
//		var domain = PREFIX + sNo + ".forio.com";
//		return domain;
//	}();
//	F.APIUtils.simulatePath = "simulate";
//	F.APIUtils.userPath = "wharton";

	//F.APIUtils.simPath = "leadership";

	return{
		initiate: function(userName, passwd){
			F.API.Auth.login(userName, passwd, function(loginInfo){
				if(loginInfo.canRunSim){
					var team = loginInfo.sessionInfo.team;
					//	var server = getServerForTeam(team);
					var server = loginInfo.user.serverId;
					var token = encodeURIComponent(loginInfo.token);
					if(server && server !== F.APIUtils.domain){
						F.API.Auth.logout(function(){//Logout from other servers; so if you do type in urls directly they cant play
							var url = "http://" + server + "/" + F.APIUtils.simulatePath + "/simulation/" +
									  F.APIUtils.userPath + "/" + F.APIUtils.simPath;
							window.location = url + "/redirect.htm?token=" + token;
						});
					}else {
						F.Net.goToURL("index.html");
					}
				}
				else{
					$("#errorMessage").text(loginInfo.message).show();
				}
			 }, {params: {token: true}});
		}
	}
}());


$(document).ready(function(){
   if(testJScript() && testFlash() && testBrowser() && testCookies())  {
	   $('#loginContent').css({display: "block"});
   }

	$("#loginid").focus();
	$("#formItself").submit(function(evt){
		evt.preventDefault();
	});

	$("#formItself .inputSubmit").click(function(evt){
		evt.preventDefault();
		$("#errorMessage").show().text("Logging you in...");
		var userName = $("#loginid").val();
		var passwd = $("#password").val();

		Login.initiate(userName, passwd);
	});

	$('#forgotPassButton').click(function(e){
		e.preventDefault();
		e.stopPropagation();
		F.API.Auth.sendPassword($('#loginid').val(), function(){
			$("#errorMessage").text('email sent!').show();
		}, "baseUrl=http://wtls.wharton.upenn.edu/simulate");
	});
});