var History = YAHOO.util.History;

nav = {

	module: 'page',
	_prevTabLocation:{},
	params: '',

	// Loads the requested page and injects into content DIV
    loadDiv: function(location, page) {
		$('#loadingMsg').show();
		page || ( page = '#content #container');

		var pageName = location;
		location = "htm/"+location+".htm?skip_redirect=true";
		if(nav.params != '') $(page).load(location+'&'+nav.params,null,function(){ nav.changePageUI(pageName); });
		else $(page).load(location,null,function(){ nav.changePageUI(pageName); });
    },
	changePageUI: function(pageName){
	  	if ($('#navigation a[href="htm/' + pageName + '.htm"]').length != 0)
		{
			var $tab = $('a[href="htm/' + pageName + '.htm"]').parent();
			$('#navigation li').removeClass('selected');
			$tab.addClass('selected');
			$('.tabs').removeClass('open');
			$tab.parent().addClass('open');
		}
		$('#loadingMsg').hide();

	},

	// Handles page changes... Adjusts class names for tabs and subnav, saves
	changePageHandler: function(page){
		nav.loadDiv(page);
	},

	// Multi-purpose goto function, can include params. Stored into yahoo history module
    goToPage: function(page,params, blah, target)
    {
		page = page || '';
		page = Util.cleanUri(page);
		nav.params = params || '';

		//This bypasses the YUI History manager and just gets->injects data. It's been useful once or twice
		if (params && params.lastIndexOf('forceLoad=true') != -1)
			nav.loadDiv(page, target);
		else
			History.navigate(nav.module,page);

		$('#loadingMsg').hide();
    },
	updatePage: function(page, params){
		var pages = [].concat(page);
		var currPage = nav.getCurrentPage();
		for(var i=0; i< pages.length; i++){
			if(currPage == pages[i]){
				this.refreshPage(params);
			}
		}
	},
	/** HardRefresh.
	 */
	refreshPage: function(params, options){
		nav.params = params;
		nav.loadDiv(nav.getCurrentPage(), params, options);
	},
	/**
	 * @return {String} Name of the current sub-section with the main tabs
	 */
	getCurrentPage:function(){
		var cp = History.getBookmarkedState(nav.module);
		if(!cp){
			cp = "usr_start";
		}
		return cp;
	},

	loadPage:function(url,params, options){
		var settings = {
			target : "#content  #container",
			callback: $.noop,
			noParse: false
		}
		$.extend(settings, options);

		var page = $(settings.target);

		$('#loadingMsg').show();

		var connsettings = {
			onSuccess: function(data){
				settings.callback(data);
			},
			onComplete: function(data){
				$("#loadingMsg").hide();
				$(page).html(data);
			}
		}

		var qs = (settings.noParse == true) ? params :   F.makeQueryString(params);
		var conn = new AjaxConnection(url, connsettings);
			conn.getHTML(qs);
	}
};

var Util = {
		formatNumber: function(nStr,format){
			var result = '';
			switch(format){
				case '$#,##0':
					result += '$';
				case '#,##0':
					nStr += '';
					var x = nStr.split('.');
					var x1 = x[0];
					var x2 = x.length > 1 ? '.' + x[1] : '';
					var rgx = /(\d+)(\d{3})/;
					while (rgx.test(x1)) {
						x1 = x1.replace(rgx, '$1' + ',' + '$2');
					}
					result += x1 + x2;
					break;
			}
			return result;
		},
		toggleCheckbox: function(input)
		{
			if ($(input).prop('checked') == false)
			{
				$(input).attr('value','0')
			}
			if ($(input).prop('checked') == true)
			{
				$(input).attr('value','1')
			}
		},
		checkboxSum: function(id,min,max,lastClicked){
					var totalChecked = 0;

					$('#'+id+' input:checked').each(function(){
						totalChecked += parseFloat($(this).attr('rel'));
					});

					if(totalChecked > max)
					{
						lastClicked.prop('checked',false);
						lastClicked.prop('value','0');

						//TODO: need to replace this with working alert or remove this
						//UI.alert('You have exceeded your budget.<br/><br/>You selected $'+totalChecked+' in incentives, when you only have $'+max+' available to you.','Note',300,200);
					}
					else
					{
						var formattedNum = Util.formatNumber(parseFloat(max - totalChecked),'$#,##0');
						$('#cash_left span').text(formattedNum);
					}
		},
		submit: function(form){
			if (form.action) var currentPage = this.cleanUri(form.action);
			else var currentPage = History.getCurrentState(nav.module);

			var inputs = [];
			$(':input:not(":button, :radio, :submit")', form).each(function() {
				inputs.push(this.name + '=' + escape(this.value));
			});
			$(':radio:checked', form).each(function() {
				inputs.push(this.name + '=' + escape(this.value));
			});
			$('.sortable li').each(function(index){
				index++;
				inputs.push('D_Factor Priority['+Globals.User.departmentID+','+index+']='+$(this).attr('id'))
			});

			var params = 'FD_ajax=true&'+inputs.join('&');

			$.ajax({
				data: params,
				dataType: 'HTML',
				type: 'POST',
				processData: false,
				url: 'htm/'+currentPage+'.htm',
				success: function(data, status){
					$('#content #container').html(data);				}
			})
		},
		post: function(url,inputs,redirectTo,callback){
			jQuery.post(url,
				inputs.join('&'),
				function(data)
				{
					if(redirectTo) nav.goToPage(redirectTo);
					if(callback) callback(data);
				}
			);
		},
		cleanUri: function(page)
		{
			if (page.lastIndexOf('.htm') != -1)
			{
				page = page.substring(0,page.lastIndexOf('.htm'));
			}
			if (page.lastIndexOf('htm/') != -1)
			{
				page = page.substring(page.lastIndexOf('htm/')+4);
			}
			return page;
		},
		insertFlashObj: function(dataURL,graphType,width,height,location)
		{
			var params = {
				scale: 'noscale',
				salign: 'lt',
				swLiveConnect: 'true',
				wmode: 'transparent',
				registerWithJS: '1'
			};
			dataURL = escape(dataURL);
			var attributes = {};
			var flashvars = {};

			var params = "";
			if(graphType.indexOf("?") !== -1){
				params = graphType.substr(graphType.indexOf("?"), graphType.length);
				graphType = graphType.substr(0, graphType.indexOf("?"));
			}
			//flashvars.dataURL = escape(dataURL);
			//swfobject.embedSWF('swf/'+graphType+'.swf' , location, width, height, '9.0.0','swf/expressInstall.swf', flashvars, params, attributes);
			var chart = new FusionCharts('swf/'+graphType+'.swf' + params, "swf_"+location, width, height, "0", "1");
			chart.addParam("WMode", "Transparent");
			chart.setDataURL(dataURL);
			chart.render(location);
		}
}

YAHOO.util.Event.onDOMReady(function()
{
	//Attaching js functions to the links
	$('#navigation li a').click(function(event){ event.preventDefault();
		nav.goToPage(this.href,null,'click'); });

	$("#unimpersonate").click(function(e){
		e.preventDefault();
		F.API.Auth.unimpersonate(function(){
			F.Net.goToURL("index.html#page=fac_summary");
		})
	});

	$('#tool_logout').bind("click.logout",function(e){
		e.preventDefault();
		if(window.HAS_DIRTY_DECISIONS === undefined){
			HAS_DIRTY_DECISIONS = false
		}

		if(HAS_DIRTY_DECISIONS === true &&
			!confirm('Your changes have not been submitted. Are you sure you want to leave the page?')){
			return false;
		}
		else{
			$('#loadingMsg').show();
			HAS_DIRTY_DECISIONS = false;
			F.API.Auth.logout(function(){
				F.Net.goToURL("login.htm");
			});
		}
	});

	function closeEditorWarning(){
		if(window.HAS_DIRTY_DECISIONS && HAS_DIRTY_DECISIONS === true){
			return 'Your changes have not been submitted. Are you sure you want to leave the page?'
		}
	}
	window.onbeforeunload = closeEditorWarning;

	$('#tool_chat').click(function(e){
		e.preventDefault();
		Sim.Chat.UI.showDialog();
	});
});