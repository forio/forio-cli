var JabberHandler = (function(){
    function Message(msgFrom, msgTo,  callbackfn, msgData){
	    var now = new Date();
	    var hrs = now.getHours();
	    if(hrs > 12) hrs = 12 - parseInt(hrs); // Convert military time to normal
	    var currtimeStamp = [hrs, now.getMinutes(),  now.getSeconds()].join(":");
	    callbackfn || (callbackfn = "");
	    return{
	        from : msgFrom,
	        to   : msgTo,
	        data : msgData,
	        callback: callbackfn,
	        timeStamp : currtimeStamp
	    }
	}
	
	var sentMessages = {};
	
	var sendMessage = function(msg){
		var payload = msg.callback;
		var data = msg.data;
		
		if(sentMessages[payload] !== data){
			//Haven't sent this message before
			Chat.send(msg); 
			sentMessages[payload] = data;
		}
	}
	
    return{
    	//Your advance event fired, let everyone else know
	    sendAdvanceNotification: function(args){
	        var advanceMsg = new Message(PLAYER, "All",  "JabberHandler.handleAdvanceNotification", args); 
	    	sendMessage(advanceMsg); 
	    },
	   
	   	//Someone else told you to advance. You'll get this message from everyone who's been polling
	    handleAdvanceNotification: function(msg){
	    	var args = msg.data;
	    	
	    	//Don't have to check if u already received before, the fireOnce takes care of it and doesn't fire twice
	    	F.Events.fireOnce(WSim.Events.roundOver, args); 
	    },
	    
	    init: function(){
	    	Event.onDOMReady(function(){
				F.Events.subscribe(WSim.Events.roundOver, sendAdvanceNotification , "JabberHandler: round over");
			});
	    }
    }
});



