WSim.UI = function(){
    var investorHandler=  function(){
        UI.investorMsg.show();
    };
    var handleTimeout=  function(){
        Sim.decisions.force();
    };

    var handleDayOver = function(args){
        Globals.Sim.timeout = false;

        UI.dialog.hide();  //Removes modal popup
        nav.goToPage('usr_start');
    };

    var handleRoundover = function(args){
        Sim.decisions.unforce();
        var round = parseInt(args.round, 10);
        var nextRound = round + 1;
        var timestamp = args.time;

        var afterStep = function(){
            Globals.Sim.timeout = false;
            Globals.Sim.stage = 0;

            UI.dialog.hide();  //Removes modal popup
            UI.dashboard.update();  //Updates year and round on top tier
            nav.goToPage('usr_dashboard');
        };
        if(Sim.Round.getCurrent() < round){
            //Someone else advanced it for u
            Sim.Round.setCurrent(round);
            afterStep();
        }
        else{
            //Advance
            Sim.Round.advanceTo(nextRound, afterStep);

            //Still need to set timestamp here since it's in-between days
            Sim.saveTimestamp(timestamp, nextRound);
        }
    };

    var handleStageOver = function(args){
        //console.log("handleStageOver", args);
        Sim.decisions.unforce();
        var stage = args.stage;
        var round = args.round;


        nav.updatePage('usr_decisions'); //This page will take care of redirecting you to the right section
        UI.dialog.hide();
        Sim.Stage.setCurrent(stage);
    };
    var handleAllVotesIn = function(args){
        //console.log("handleAllVotesIn", args);
        var hasConsensus = args.consensus;
        var round = args.round;

        var stage = parseInt(args.stage, 10);
        var nextStage = stage + 1;

        var isConsensusRequired = (round === 0 || round == 3 || (round == 6 && stage == 1));
        var isMultiStageRound = (round==5 || round ==6 || round ==7);

        var isDuplicateRoles = args.duplicateRoles;

        if(isConsensusRequired && !hasConsensus){ //Highlight error
            var type = (round === 0) ? 'collision' : 'mismatch';
            UI.dialog.setContent(type);
            UI.dialog.show('yellow');
        }
        else{
            if(isMultiStageRound){
                Sim.Stage.advanceTo(nextStage);
            }
            else{
                Sim.Round.flagReadyToAdvance(); //Don't advance yet because we want them to hit the survey page;
            }
        }
    };

    var handleUserSubmitted = function(users){
        if(Dom.inDocument("unfinished") && $("#unfinished:visible").size() > 0){
            $("#unfinished").text(users);
        }
    };
    return{
        init: function(){
            Event.onDOMReady(function(){
                F.Events.subscribe(WSim.Events.dayOver, handleDayOver , "WSim.UI: day over");
                F.Events.subscribe(WSim.Events.roundOver, handleRoundover , "WSim.UI: round over");
                F.Events.subscribe(WSim.Events.stageOver, handleStageOver , "WSim.UI: stage over");
                F.Events.subscribe(WSim.Events.timeOut, handleTimeout , "WSim.UI: Time is up");
                F.Events.subscribe(WSim.Events.allVotesIn, handleAllVotesIn , "WSim.UI: allVotesIn");
                F.Events.subscribe(WSim.Events.readyToInvest, investorHandler , "WSim.UI: ceo readyToInvest");
                F.Events.subscribe(WSim.Events.userSubmitted, handleUserSubmitted , "WSim.UI: handleUserSubmitted");
            });
        }()
    };
}();


WSim.UI.Timer = function(){
    var time = 9999;
    var interval = 9999;
    var initiated = false;
    var internalTimer;
    var POLL_INTERVAL = 1000;

    var onDecrement= function(){
        time = time - 1;
        var mins = 0;
        var secs = time;
        if(time >= 60){
            mins = parseInt(time / 60, 10);
            secs = time % 60;
        }
        if(mins < 10) mins = "0"+mins;
        if(secs < 10) secs = "0"+secs;

        if(time< (interval * 0.25)){
            $("#timeLeft").addClass("done");
        }
        else if(time < (interval * 0.5)){
            $("#timeLeft").addClass("almostDone");
        }
        else{
            $("#timeLeft")
                .removeClass("done almostDone");
        }
        if(time >= 0){
            $("#mins").text(mins);
            $("#secs").text(secs);
        }
        else{
            $("#mins, #secs").text('00');
        }
    };

    var initTimer = function(){
        $("#timeLeft").show();
        internalTimer = YAHOO.lang.later(POLL_INTERVAL, this, onDecrement, null, true);
        initiated = true;
    };

    //Save current time to with server later
    var syncTimeForNextRound = function(args){
        var timestamp = args.time;
        var nextround = parseInt(args.round, 10) + 1;

        //Sim.saveTimestamp(timestamp, nextround);
    };
    var syncTimeForNextStage = function(args){
        var stage = parseInt(args.stage, 10);
        var timestamp = args.time;

        Sim.saveTimestamp(timestamp, "", stage);
    };

    var handleTimeChange = function(args){
        if(!initiated) initTimer();

        var timeLeft = args[0];
        var totalTime = args[1];

        WSim.UI.Timer.setTime(timeLeft, totalTime);

        //console.log("time change" + timeLeft + totalTime);
        //nav.goToPage("decisions");
    };

    var removeTimer = function(){
        internalTimer.cancel();
        $("#timeLeft").remove();
    };
    var handleGameOver = function(args){
        removeTimer();
    };
    var handleDayOver = function(args){
        removeTimer();
    };

    return{
        setTime: function(timeLeft, totalTime){
            //console.log("setTime", timeLeft, totalTime)
            time = timeLeft;
            interval = totalTime;
            if(!initiated){
                initTimer();
            }
        },
        stop: function(){
            if(initiated){
                if(internalTimer) internalTimer.cancel();
                initiated = false;
            }
        },
        initTimer: initTimer,
        init: function(){
            Event.onDOMReady(function(){

                if(!Globals.Sim.isFirstRoundofTheDay){
                    initTimer();
                }

                F.Events.subscribe(WSim.Events.dayOver, handleDayOver , "WSim.UI.Timer: day over");
                F.Events.subscribe(WSim.Events.timeChanged, handleTimeChange , "WSim.UI.Timer: time changed");
                F.Events.subscribe(WSim.Events.roundOver, syncTimeForNextRound , "WSim.UI.Timer: round over");
                F.Events.subscribe(WSim.Events.stageOver, syncTimeForNextStage , "WSim.UI.Timer: stage over");
                F.Events.subscribe(WSim.Events.gameOver, handleGameOver , "WSim.UI.Timer: game over");
            });
        }()
    };
}();