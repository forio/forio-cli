
WSim.UI.Round4 = function(){

	function checkLeader(){
		if(jQ('#task4Toggle').prop('checked') && jQ("#member_leader").val() == 0){
			Sim.decisions.flagInvalid(jQ("#member_leader").get(),'You must pick someone as a leader!');
		}
		else{
			Sim.decisions.removeFlagInvalid(jQ("#member_leader").get());
		}
	}
	
	function prioSelect(obj){
		var $firstSelect = $(obj);
		var firstIndex = parseInt(obj.id.replace('prio_select_',''));
	
		$('.prio_select').each(function(){
			if(this.id != 'prio_select_'+firstIndex && $(this).attr('value') == $firstSelect.attr('value'))
			{
				$(this).attr('value',$firstSelect.data('value'));
			}
		});
		$('.prio_select').each(function(){
			$(this).data('value',$(this).attr('value'));
		});	
	}
		

	return{
		init: function(){
			YAHOO.util.Event.onDOMReady(function(){
				jQ("#task_1").click(function(evt){
					evt.preventDefault();
					$('#hide_task_3, #hide_task_2, #hide_task_5').hide();
					$('#hide_task_1').toggle(); 
				});
				jQ("#task_2").click(function(evt){
					evt.preventDefault();
					$('#hide_task_1, #hide_task_3, #hide_task_5').hide(); 
					$('#hide_task_2').toggle();
				});
				jQ("#task_3").click(function(evt){
					evt.preventDefault();
					$('#hide_task_1, #hide_task_2, #hide_task_5').hide(); 
					$('#hide_task_3').toggle();
				});
				jQ("#task_5").click(function(evt){
					evt.preventDefault();
					$('#hide_task_1, #hide_task_2, #hide_task_3').hide(); 
					$('#hide_task_5').toggle();
				});
		
				$('#newHiresTableDiv').remove().appendTo("#extra_info");

				$('.prio_select').each(function(){
					$(this).data('value',$(this).attr('value'));
				});
		
				$('.prio_select').change(function(){
					prioSelect(this);
					var postStr = '?FD_ajax=true';
		
					$('.prio_select').each(function(){
						postStr += '&'+$(this).attr('name')+'='+$(this).find('option:selected').attr('value');
					});
					jQuery.post('include/empty.txt',postStr);
				});
		
				//Toggle task 4 div; TODO: check if this post on change is required, we're already posting this on submit anyway
				jQ("#divToggleTask4 :radio, #divToggleTask4 select").bind("change.toggleTask", function(){
					var inputTask = jQ('#task4Toggle');
					if(inputTask.prop('checked') == true){
						jQ('#hide_task_4').show();
						jQ('#hiddenInputLeader').attr('value',jQ('#member_leader').attr('value'));
					}
					else{
						jQ('#hide_task_4').hide();
						jQ('#hiddenInputLeader').attr('value','0');
					}
					checkLeader();
					jQ.post('include/empty.txt','D_Member Leader[' + Globals.User.role +
						']='+jQ('#hiddenInputLeader').attr('value'));
				}).trigger("change.toggleTask");

				//Validation check for team selection part (has to pick at least 3 people)	
				$('#newHiresTable :checkbox').bind("change.validate", function(){
						var countChecks = 0
						$('#newHiresTable :checkbox').each(function(){
							if($(this).prop('checked') == true) countChecks++;
						});
						if(countChecks < 3) {
							$('.inputSubmit').prop('disabled','disabled');
						}
						else {
							$('.inputSubmit').removeAttr('disabled');
						}
				}).trigger("change.validate");
				jQ(".prio_select option:first").trigger('change');
			});
		
		}
	}
}()