YAHOO.util.Event.onDOMReady(function()
{
    var bookmarkedState = History.getBookmarkedState(nav.module);
    var initialState = bookmarkedState || 'fac_results/summary';

    History.register(nav.module, initialState, nav.changePageHandler);
    History.onReady(function(){ nav.changePageHandler(History.getCurrentState(nav.module)); });
    History.initialize('yui-history-field', 'yui-history-iframe');

});

jQuery.tablesorter.addParser({
    id: 'commaremover',
    is: function(s) {
        // return false so this parser is not auto detected
        return false;
    },
    format: function(s) {
        // format your data for normalization
        s = s.replace("$","");
        s = s.replace(",","");
        s = s.replace("%","");
        //console.log(s);
        if($.trim(s) == ""){
            s =  -Infinity;
        }
        return s;
    },
    // set type, either numeric or text
    type: 'numeric'
});


var Fac = function(){
    var TIMER_INTERVAL = 600000;
    var pc = new PollingConnection("include/empty.txt", {}, {interval: TIMER_INTERVAL});

    var TOKEN = "";

    var SERVER_LIST= ["wharton1.forio.com", "wharton2.forio.com", "wharton3.forio.com", "wharton4.forio.com"];
    if(!F.Array.contains(F.APIUtils.domain, SERVER_LIST)){
        //Push current server; i.e., if you're on wharton-magic or some other test server
        SERVER_LIST.push(F.APIUtils.domain);
    }

    var getServerForTeam = function(team){
        team= team+"";
        if(team.indexOf(",") !== -1){
            team = team.split(",").reverse()[0];
        }
        var server = SERVER_TEAM_LIST[+team];
        if(!server)
            server = F.APIUtils.domain;
        return server;
    };
    var saveToServer = function(qs, callback, server){
        qs+= "&token=" + TOKEN;
        var olddomain = F.APIUtils.domain;
        F.APIUtils.domain = server;

        F.API.Run.connect(qs, callback);

        F.APIUtils.domain = olddomain;
    };
    return{
        run: function( qs, team, callback){
            if(team === "*" || !team){
                qs += "&team=*";
                var sl = SERVER_LIST.slice();

                var save = function(){
                    var thisServer = sl.pop();
                    if(sl.length){
                        //More servers left to post to
                        saveToServer(qs, save, thisServer);
                    }
                    else{
                        saveToServer(qs, callback, thisServer);
                    }
                };
                save();
            }
            else{
                var server = getServerForTeam(team);
                qs+= "&team=" + team;
                saveToServer(qs, callback, server);
            }
        },
        impersonate: function(user, server,group, callback){
            if(!server || server === F.APIUtils.domain){
                F.API.Auth.impersonate(user, group, callback);
            }
            else{
                F.API.Auth.logout(function(){
                //YES THIS IS A HACK. CHANGE SIMULATE TO GIVE ME BACK TOKENS IN THE API RESPONSE SO I CAN LOGIN WITHOUT TOKEN
                var ADMIN_USER = "wtls";
                var ADMIN_PASS = "redcar";

                var olddomain = F.APIUtils.domain;
                F.APIUtils.domain = server;

                F.API.Auth.login(ADMIN_USER, ADMIN_PASS, function(r){
                    var token = r.token;
                    F.API.Auth.impersonate(user, group, callback, {params: "token="+token});
                    F.APIUtils.domain = olddomain;
                });
                });

            }
        },
        setData: function(team, decision){

        },
        getToken: function(){
            return TOKEN;
        },
        init: function(){
            pc.init();
            F.API.Auth.getUserInfo(function(r){
                TOKEN = r.token;
            });
        }()
    };
}();

Fac.UI = {
    initClipboard: function(tblId){
        $(function(){
            ClipBoard.init("copy_tbl_" + tblId,
                {datasource: "ClipBoard.copyTable('#tbl_" + tblId +"')",
                 swfPath: "swf/ClipBoard.swf",
                 icon: "../img/page_white_paste.png"
                },
                {width: 145,height: 30})
        });
    }
};
Fac.UI.Results = function(){
    var toggleRow = function(){
        var $cells  = $(this)
                        .siblings("td")
                        .children("p")
        if(!$(this).hasClass("visible")){
            //its already shown, go in and hide stuff
            $cells.removeClass("inv")
                .addClass("visible");
        }
        else{
            $cells.removeClass("visible")
                .addClass("inv");
        }

        $(this).toggleClass("visible");
    }

    var toggleColumn= function(){
        var index = $(this).parent("tr").children().index(this) + 1;
        var $cells  = $(this).parents("table").find('td:nth-child('+ index +') p');

        if(!$(this).hasClass("visible")){
            //its already shown, go in and hide stuff
            $cells.removeClass("inv").addClass("visible");
        }
        else{
            //$cells.removeClass("visible").addClass("inv");
        }

        $(this).toggleClass("visible");
    }

    var toggleCell= function(){
        //Ridonculous; jquery doesn't handle tds with visibility:hidden! added an extra pointless p tag in markup
        //console.log("hfdas")
        $(this)
            .children("p")
                .toggleClass("inv")
                .toggleClass("visible");
    }
    var toggleTable= function(evt){
        evt.preventDefault();

        var tblId = this.id.replace("toggle_", "");
        //$(Dom.get(tblId)).toggleClass("inv");

        var $tbl = $(Dom.get(tblId));

        if($tbl.hasClass("inv")){
            //It's hidden so unhide everything now
            var x = $tbl
                .find("p,tr")
                    .removeClass("inv")
                    .addClass("visible")
                    .end()
                .find("th")
                    .addClass("visible");
            //console.log(x)
        }
        else{
            $tbl
                .find("p,tr")
                    .removeClass("visible")
                    .addClass("inv")
                    .end()
                .find("th")
                    .removeClass("visible");
        }
        $tbl.toggleClass("inv");
    }

    var toggleChart= function(evt){
        evt.preventDefault();

        var tblId = this.id.replace("toggle_", "");
        $(Dom.get(tblId)).toggleClass("inv");
    }
    return{
        init: function(){

            var cc  = $("table.controlTable  td").get();
            if(cc.length > 0)
                 Event.on(cc, "click", toggleCell) //Dammit jquery

            $("table.controlTable")
                .delegate("tbody th", "click.toggle",toggleRow)
                .delegate("thead th", "mouseup.toggle",toggleColumn);

            $("a.tblToggle")
                .bind("click.toggle", toggleTable);

            $("a.graphToggle")
                .bind("click.toggle", toggleChart);
        }
    }
}();

Fac.UI.Bootstrap = function () {

    var saveCountries = function (evt) {
        evt.preventDefault();
        var vals = $("#tbl_country_list .country :text").get();
        F.API.Data.saveAs("marketNames", vals, function () {
            alert("Changes saved.")
        }, {scope: "GROUP"})

    }

    return {
        init: function () {
            $(function () {
                $("#tbl_country_list")
                    .delegate("#saveCountries", "click", saveCountries);
            });
        }
    }
}();

Fac.UI.Control = function(){
    var cb = function(){
        nav.refreshPage()
    }
    var handleTeamReset = function(evt){
        $('#loadingMsg').show();
        evt.preventDefault();
        var teamId = this.id.replace("reset_team_", "");
        Fac.Sim.reset(teamId, cb);
    }
    var handleTeamRewind = function(evt){
        evt.preventDefault();
        $('#loadingMsg').show();
        var params = this.id.replace("rewind_team_", "").split("_");
        var team = params[0];
        var runid = params[1];
        var round = params[2];

        Fac.Sim.rewind(team, runid, round, cb);
    }
    var handleTeamRewindStage = function(evt){
        evt.preventDefault();
        $('#loadingMsg').show();
        var params = this.id.replace("rewindstage_team_", "").split("_");
        var team = params[0];
        var runid = params[1];
        var round = params[2];
        var stage = params[3];

        Fac.Sim.rewindStage(team, runid, round, stage, cb);
    }

    var handleTeamTimerReset = function(evt){
        evt.preventDefault();
        $('#loadingMsg').show();
        var params = this.id.replace("reset_timer_team_", "").split("_");
        var runid = params[0];
        var round = params[1];

        Fac.Sim.resetTimer(runid, round, cb);
    }

    var handleTeamAdvance = function(evt){
        evt.preventDefault();
        $('#loadingMsg').show();
        var teamId = this.id.replace("advance_team_", "");
        Fac.Sim.advance(teamId, cb);
    }


    var handle5PlayerToggle = function(evt){
        evt.preventDefault();
        $('#loadingMsg').show();
        var teamId = this.id.replace("fivepmode_team_", "");
        var is5Player = !$(this).hasClass("on");
        Fac.Team.mark5Player(teamId, is5Player, cb);
    }

    var handleCompNameChange = function(evt){
        evt.preventDefault();
        $('#loadingMsg').show();

        var runId = this.id.replace("set_compName_", "");
        var newName = Dom.get("compName_" + runId).value;

        Fac.oops.changeTeamName(runId, newName, cb);
    }

    var handleCEOChange = function(evt){
        evt.preventDefault();
        $('#loadingMsg').show();

        var team = this.id.replace("change_CEO_", "");
        var CEO  = Dom.get("CEO_" + team).value;

        Fac.Team.changeCEO(team, CEO, cb);
    }
    return{
        init: function(){
            $("#tbl_team_controlinfo")
                .delegate("a.rewind", "click.act",handleTeamRewind)
                .delegate("a.rewindstage", "click.act",handleTeamRewindStage)

                .delegate("a.resetTimer", "click.act",handleTeamTimerReset)
                .delegate("a.advance", "click.act",handleTeamAdvance)
                .delegate("a.reset", "click.act",handleTeamReset)
                .delegate("a.fiveplayer", "click.act",handle5PlayerToggle)
                .delegate("a.cName", "click.act", handleCompNameChange)
                .delegate("a.changeCEO", "click.act", handleCEOChange);

            $("#btnAdvanceAll").click(function(){
                Fac.Sim.goToNextDay();
            });
        }
    }
}();


Fac.UI.ExtraGameSettings = function(){
    var cb = function(){
       $("#notification")
        .text("Saved!")
        .fadeOut(1000)
    }
    return{
        init: function(){
             jQ("#simControls").find(".investTime,.investRoom,.budgetRoom,.videoRoom,.funding").bind("click.notify", function(){
                 $("#notification")
                    .text("Saving..")
                    .fadeIn(1000)
             });

            jQ("#simControls .investTime").click(function(evt){
                evt.preventDefault();

                var teamId = this.id.replace("set_investmentTime_", "");
                var hrs = parseInt(jQ("#investmentHrs_"+teamId).val());
                var mins = parseInt(jQ("#investmentMins_"+teamId).val());

                var notifyHrs, notifyMins;
                if(mins >=15){
                    notifyHrs = hrs;
                    notifyMins = mins - 15;
                }
                else{
                    notifyHrs = hrs - 1;
                    notifyMins = 60 + mins - 15;
                }

                $("#investmentHrs_notify_"+ teamId).val(notifyHrs);
                $("#investmentMins_notify_"+ teamId).val(notifyMins);

                Fac.Team.setInvestorTime(teamId, notifyHrs, notifyMins, cb);
            });

            jQ("#simControls .investRoom").click(function(evt){
                evt.preventDefault();

                var teamId = this.id.replace("set_investmentRoom_", "");
                var room = jQ("#investmentRoom_"+teamId).val();
                Fac.Team.setInvestorRoom(teamId, room, cb);
            });

            jQ("#simControls .budgetRoom").click(function(evt){
                evt.preventDefault();

                var teamId = this.id.replace("set_budgetRoom_", "");
                var room = jQ("#budgetRoom_"+teamId).val();
                Fac.Team.setBudgetRoom(teamId, room, cb);
            });

            jQ("#simControls .videoRoom").click(function(evt){
                evt.preventDefault();

                var teamId = this.id.replace("set_videoRoom_", "");
                var room = jQ("#videoRoom_"+teamId).val();
                Fac.Team.setVideoRoom(teamId, room, cb);
            });

            jQ("#simControls .funding").click(function(evt){
                evt.preventDefault();

                var teamId = this.id.replace("set_funding_", "");
                var funding = jQ("#funding_"+teamId).val();
                Fac.Team.setFunding(teamId, funding, cb);
            });
        }
    }
}();
Fac.UI.Settings = function(){
    var cb = function(){
        $('#loadingMsg').hide();
        nav.refreshPage();
    }

     var handleBoostClick = function(){
         var teamId = this.id.replace("boost_team_", "");
         $('#loadingMsg').show();

         if($(this).hasClass("Activate")){
             $(this).removeClass("Activate");
             Fac.Team.activateBoost(teamId, cb);
         }
         else{
             $(this).addClass("Activate");
             Fac.Team.deactivateBoost(teamId, cb);
         }
     }

    var handleTeamAdvance = function(evt){
        evt.preventDefault();
        $('#loadingMsg').show();
        var teamId = this.id.replace("advance_team_", "");
        Fac.Sim.advance(teamId, cb);
    }

     var handleSimStateToggle = function(){
         var teamId = this.id.replace("open_team_", "");
         $('#loadingMsg').show();

         if($(this).hasClass("Open")){
             $(this).removeClass("Open");
             Fac.Sim.close(teamId, cb);
         }
         else{
             $(this).addClass("Open");
             Fac.Sim.open(teamId, cb);
         }
     }

      var handleSimOpen = function(evt){
          evt.preventDefault();
          $('#loadingMsg').show();
          Fac.Sim.open("*", cb);
     }

      var handleSimClose = function(evt){
          evt.preventDefault();
          $('#loadingMsg').show();
          Fac.Sim.close("*", cb);
     }

     var handleCohortAdvance = function(evt){
         evt.preventDefault();
         var cohortName = this.id.replace("lnkAdvanceCohort_", "");
         var cohortTeams = Dom.get("cohort_teams_" + cohortName).value;
         Fac.Sim.advance(cohortTeams, cb);
     }
     var handleCohortOpen = function(evt){
         evt.preventDefault();
         var cohortName = this.id.replace("lnkOpenCohort_", "");
         var cohortTeams = Dom.get("cohort_teams_" + cohortName).value;
         Fac.Sim.open(cohortTeams, cb);
     };
     var handleCohortClose = function(evt){
         evt.preventDefault();
         var cohortName = this.id.replace("lnkCloseCohort_", "");
         var cohortTeams = Dom.get("cohort_teams_" + cohortName).value;
         Fac.Sim.close(cohortTeams, cb);
     };

     var showLoading = function(){
        $('#loadingMsg').show();
     };

     var handleStartTimerForCohort = function (evt) {
         evt.preventDefault();
         var cohortName = $(this).data("cohort");
         var cohortRuns = Dom.get("cohort_runs_" + cohortName).value;
         var round = $(this).data("round");

         if(confirm("Are you sure you want to start the timer for Cohort " + cohortName + " ?")) {
            Fac.Cohort.startTimer(cohortRuns.split(','), round, cb);
         }
     };
    return{
        init: function(){
            $("#tbl_settings")
                .delegate("a.boost", "click.act",handleBoostClick)
                .delegate("a.simstate", "click.act",handleSimStateToggle)
                .delegate("a.advance", "click.act",handleTeamAdvance)
                .delegate("a.advanceCohort", "click.act",handleCohortAdvance)
                .delegate("a.openCohort", "click.act",handleCohortOpen)
                .delegate("a.closeCohort", "click.act",handleCohortClose)
                .delegate("a.startTimer", "click.act",handleStartTimerForCohort);

            $("#tbl_settings")
                .delegate("a", "click.load",showLoading);
            $("#lnkCloseSim").bind("click", handleSimClose);
            $("#lnkOpenSim").bind("click", handleSimOpen);
        }
    }
}();


Fac.UI.Adjust = function(){
    var cb = function(){
        nav.refreshPage()
    }

    var handleBoostClick = function(){
        var teamId = this.id.replace("boost_team_", "");
        $('#loadingMsg').show();

        if($(this).hasClass("Activate")){
            $(this).removeClass("Activate");
            Fac.Team.activateBoost(teamId, cb);
        }
        else{
            $(this).addClass("Activate");
            Fac.Team.deactivateBoost(teamId, cb);
        }
    }

    var handleSaveResultsClick = function(){
        var teamId = this.id.replace("saveresults_team_", "");
        $('#loadingMsg').show();
        Fac.Team.saveResults(teamId, cb);
    }

    var handleDecisionSetClick = function(){
        var idBreakPos = this.id.lastIndexOf("_");
        var teamId = this.id.substring(idBreakPos + 1);
        var varName = this.id.substring(0, idBreakPos).replace("set_", "");

        // use Dom since the name may have spaces/brackets
        var textElementName = "D_" + varName + "_" + teamId;
        if (!Dom.get(textElementName))
        {
            alert("Couldn't find field with id '" + textElementName + "'");
            if (cb)
            {
                cb();
            }
        }
        else
        {
            var varValue = Dom.get(textElementName).value;
            $('#loadingMsg').show();
            Fac.Team.setTeamDecision(varName, varValue, teamId, cb);
        }
        return false;
    }

      var handleSimOpen = function(evt){
          evt.preventDefault();
          $('#loadingMsg').show();
          Fac.Sim.open("*", cb);
     }

      var handleSimClose = function(evt){
          evt.preventDefault();
          $('#loadingMsg').show();
          Fac.Sim.close("*", cb);
     }
    return{
        init: function(){
            $("#tbl_team_info")
                .delegate("a.boost", "click.act",handleBoostClick)
                .delegate("a.saveResults", "click.act",handleSaveResultsClick)
                .delegate("a.decisionSet", "click.act",handleDecisionSetClick)
                ;

            $("#lnkCloseSim").bind("click", handleSimClose);
            $("#lnkOpenSim").bind("click", handleSimOpen);
        }
    };
}();

Fac.Cohort = function () {

   return {
        startTimer: function (runs, round, callback) {
            var timestamp = (new Date()).valueOf();

            timestamp += (5 * 60 * 1000); //5 min warning

            var formattedTime = new Date(parseInt(timestamp, 10)).toGMTString();
            var key =  ["timer", "round_" + round, "stage_0"].join("/");

            var posts = [];
            for(var i=0; i<runs.length; i++){
                posts.push( F.API.Data.saveAs(key, "time=" + timestamp + "&formattedTime=" + formattedTime, $.noop, {run: runs[i]}) );
            }
            $.when.apply(null, posts).then(callback);
        }
   };
}();


Fac.Team = function(){
    var setDecision = function(qs, team, callback){
        Fac.run(qs,team,callback);
    }

    return{
        mark5Player: function(team, is5Player, callback){
            var noOfPlayers = (is5Player) ? 5 : 6;
            var params = "D_NumberOfPlayers="+ noOfPlayers;
            setDecision(params, team, callback);
        },
        setInvestorTime: function(team, hrs, mins, callback){
            team || (team = User.team);

            hrs = parseInt(hrs);

            $.get("include/fac_investor_time.txt", function(response){
                var response = $.parseJSON(response);
                var time = parseInt(response.time);
                var d= new Date(time);

                    d.setDate(29);
                    d.setFullYear(2012)
                    d.setMonth(7); // Starts at index 0. Aug = 7

                    d.setHours(hrs);
                    d.setMinutes(mins);

                var ms = d.valueOf();

                var diff = time - ms;
              //  console.log(d, ms, diff);
                F.API.Data.saveAs("investmentMeetingTime/" + team, {time: ms, hrs: hrs, mins: mins}, callback, {scope:"group"});
            })

        },
        setInvestorRoom: function(team, room, callback){
            team || (team = User.team);
            F.API.Data.saveAs("investmentMeetingRoom/" + team, {room: room}, callback, {scope:"group"});
        },

        setBudgetRoom: function(team, room, callback){
            team || (team = User.team);
            F.API.Data.saveAs("budgetMeetingRoom/" + team, {room: room}, callback, {scope:"group"});
        },

        setVideoRoom: function(team, room, callback){
            team || (team = User.team);
            F.API.Data.saveAs("videoMeetingRoom/" + team, {room: room}, callback, {scope:"group"});
        },

        activateBoost: function(team, callback){
            setDecision("D_Boost Team=1&run_set=saved:true", team, callback);
        },
        deactivateBoost: function(team, callback){
            setDecision("D_Boost Team=0&run_set=saved:true", team, callback);
        },

        saveResults: function(team, callback){
            setDecision("run_set=saved:true", team, function() {Fac.Team.clearCache(callback)} );
        },

        setTeamDecision: function(varname, val, team, callback){
            setDecision("D_" + varname + "=" + val, team, callback);
        },

        clearCache: function(callback){
            var url = '../../../api/cache/values?method=DELETE';
            var ac = new AjaxConnection(url);
            ac.get("",  callback);
        },

        changeCEO: function(team, newCEO, callback){
            var sels = {};
            for(var i=1; i<=6; i++){
                sels["D_CEO Selection[" + i + "]"] = newCEO

            }
            var qs = F.makeQueryString(sels, {encode: false});
            qs += "&run_set=saved:true"
            setDecision(qs, team, callback);
        },

        setFunding: function(team, funding, callback){
            setDecision("D_Funding Fraction=" + funding, team, callback);
        }

    }
}();

Fac.Sim = function(){
    var doAction = function(action, team, callback){
        Fac.run("run_action="+ action,team,callback);
    }
    var setDecision = function(qs, team, callback){
        Fac.run(qs,team,callback);
    }

    var deleteData = function(key, run, callback){
        F.API.Data.remove(key, callback, "run=" + run);
    }
    return{
        open: function(team, callback){
            setDecision("D_DecisionsOn=1", team, callback);
        },
        close: function(team, callback){
            setDecision("D_DecisionsOn=0", team, callback);
        },
        advance: function(team, callback){
            doAction("step", team, callback);
        },
        reset: function(team, callback){
            doAction("reset", team, callback);
        },
        rewind: function(team, run, round, callback){
            var prevRound = round - 1;
            doAction("go_back", team, function(){
                    var vals = [
                        'D_All Round Decisions Made[1]=0',
                        'D_All Round Decisions Made[2]=0',
                        'D_All Round Decisions Made[3]=0',
                        'D_All Round Decisions Made[4]=0',
                        'D_All Round Decisions Made[5]=0',
                        'D_All Round Decisions Made[6]=0'
                    ].join("&");
                setDecision(vals, team, function(){
                    deleteData("timer/round_" + round, run);
                    deleteData("timer/round_" + prevRound, run, callback);
                });
            });
        },
        rewindStage: function(team, run, round, stage, callback){
            var prevstage = stage - 1;
            var vals = [];
            for(var i=1; i<7; i++){
                vals.push('D_All Stage Decisions Made['+i+']=0');
                vals.push('D_Decisions Stage Per Player['+i+']=' + prevstage);
            }
            setDecision(vals.join("&"), team, function(){
                deleteData("timer/round_" + round + "/stage_" + stage, run);
                deleteData("timer/round_" + round + "/stage_" + prevstage, run, callback);
            });
        },
        resetTimer: function(run, round, callback){
            deleteData("timer/round_" + round, run, callback);
        },
        goToNextDay: function(callback){
            doAction("Step", "*", callback);
        }
    }
}();

Fac.oops = {
    //Undo changes by teams
    changeTeamName: function(run, newName, callback){
        newName = newName.replace(/"/g, "'") ;
        F.API.Data.saveAs("company", "name="+ newName, callback, {run:run});
    },

    changeCeo: function(team, newCEO, callback){

    }
}