if(F === undefined){
	var F =  {}
}

F.Events = function(){
	//Function to avoid double subscribing to a event
	 var subscribe = function(targetEvent, callback, eventDescription){
	 	//console.log("subs", targetEvent, callback)
        var objForEvent = {
            text: eventDescription,
            type: "custom obj"
        }
        var alreadySubscribed = false;
        for(var i in targetEvent.subscribers){
            var thisSubs = targetEvent.subscribers[i];
            if(thisSubs && thisSubs.obj && thisSubs.obj.text && thisSubs.obj.text === objForEvent.text){
                alreadySubscribed = true;
                break;
            }
        }
        if(!alreadySubscribed){
            targetEvent.subscribe(callback, objForEvent);
        }
    }
    
	 //Flags to make sure these messages aren't triggered more than once
	var firedFlag = {};
	
	return{
		subscribe: function(targetEvent, callback, eventDescription){
			subscribe(targetEvent, callback, eventDescription);
		}, 
		fireOnce: function(targetEvent, params, key){
			var key = ([].concat(key)).join(",");
			var type = targetEvent.type;
			//console.log(firedFlag[type], "params", key);
			if(firedFlag[type] && firedFlag[type] == key){
				//doNothing. This event has already been fired with these exact params;
				//console.log("not firing")
			}
			else{
				//console.log("firing")
				targetEvent.fire(params);
				firedFlag[type] = key;
			}
		},
		reset: function(){
			firedFlag = {};
		},
		fire: function(targetEvent, params){
			// console.log(targetEvent, params)
			targetEvent.fire(params);
		}
	}
}()