Sim.Chat = function(){
    var handleMessageReceived = function(msg){
        //console.log("handleMessageReceived", msg);

        Sim.Chat.UI.showDialog();

        var sender = msg.data.fromNickname;
        var text =  msg.data.message;
        var target = msg.data.toNickname;
        Sim.Chat.UI.append(sender, text, target);
    };

    var handlePlayerLeave = function(player){
        Sim.Chat.UI.markOffline(player.path);
    };
    var handlePlayerJoin = function(player){
        Sim.Chat.UI.markOnline(player.path);
    };
    return{
        sendMessage: function(to,toNick, text){
            //console.log("sendMessage", to, text);
            MChannel.Chat.sendMessage(to,toNick, text);
        },
        init: function(){
            MChannel.Chat.init(ID, NICK, Globals.cometd, {
                onConnect: function(){
                    Sim.Chat.UI .setTitle("Connected");
                },
                onDisconnect: function(){
                    Sim.Chat.UI .setTitle("Disconnected");
                }
            });
            MChannel.Chat.incomingMsgEvent.subscribe(handleMessageReceived);
            MChannel.Chat.playerLeaveEvent.subscribe(handlePlayerLeave);
            MChannel.Chat.playerJoinEvent.subscribe(handlePlayerJoin);
        }()
    };
}();

Sim.Chat.UI = function(){
    var handleSendMessage = function(evt){
        evt.preventDefault();

        var strMessage = $.trim(jQ("#chat_input textarea").val());
        if(strMessage !== ""){
            var target = $("#lstChatList").val();
            var targetNick =  $("#lstChatList :selected").text();

            jQ("#chat_input textarea").val("");
            Sim.Chat.UI.append("me",strMessage, targetNick);
            Sim.Chat.sendMessage(target,targetNick, strMessage);
        }
    };
    return {
        markOffline: function(playerPath){
            var elem = $("#lstChatList option[value=" + playerPath + "]" );
                elem
                    .text(elem.text() + " (offline)")
                    .attr("disabled", true);
        },
        markOnline: function(playerPath){
            var elem = $("#lstChatList option[value=" + playerPath + "]" );
            elem
                .text(elem.text().replace("(offline)", ""))
                .attr("disabled", false);
        },

        hideDialog:function(){
            dialog.hide();
        },
        showDialog: function()  {
            dialog.show();
        },
        setTitle: function(header) {
            dialog.setHeader('&nbsp;&nbsp;'+header);
        },

        append: function(sender, text, target){
            target = $.trim(target);

            if(target == NICK) target = "you";
            var message =  "<em>" + sender + "</em>: (to " + target + ") " + text;
             $("#chat_area #chat_text").append("<p>"+message+"</p>");
            var $apr = $("#chat_text");
            $apr.attr({ scrollTop: $apr.attr("scrollHeight") });
        },
        init: function(){
            Event.onDOMReady(function(){
                $("#chat_input textarea").bind("keypress", function(event){
                    if (event.which == '13') {handleSendMessage(event);}
                });
                jQ("#send_chat").bind("click",handleSendMessage);

                dialog = new YAHOO.widget.Panel("chtWindow",
                                {  width:"360px",
                                  zIndex:11,
                                  visible:false,
                                  draggable: true,
                                  modal:false,
                                  close: true,
                                  constraintoviewport:true } );
                dialog.render();
            });
        }()
    };
}();
