var Sim = {
	logout: function(clearDecisions){
		if(clearDecisions)
			HAS_DIRTY_DECISIONS = false;
		F.API.Auth.logout(function(){
			F.Net.goToURL("login.htm");
		});
	},
	reset: function(){
		F.API.Data.remove('surveys-4', null, {scope: "USER"});
		F.API.Data.remove('surveys-6', null, {scope: "USER"});
		F.API.Data.remove('surveys-8', null, {scope: "USER"});
		F.API.Data.remove('surveys-10', null, {scope: "USER"});
		F.API.Data.remove('survey_personality', null, {scope: "USER"});
		F.API.Data.remove('personal_metrics', null, {scope: "USER"});
		F.API.Data.remove('timer');

		F.API.Run.doActions("reset","",function(){
			nav.goToPage('usr_start');
			UI.dashboard.reset();
			F.Events.reset();

			F.API.Run.saveValues("D_DecisionsOn=1");
			Sim.Round.setCurrent(1);
			Sim.Stage.setCurrent(0);
		});
	},
	undoReadyToAdvance: function(){
		var decisionStr = 'D_All Round Decisions Made[' + Globals.User.departmentID + '] = 0&run_set=saved:true';
		F.API.Run.saveValues(decisionStr);
	},

	saveTimestamp: function(timestamp, round, stage, callback){
		if(!round) (round = Sim.Round.getCurrent());
		if(!stage) (stage = 0);

		var save = function(timestamp){
			var formattedTime = new Date(parseInt(timestamp, 10)).toGMTString();
			var key =  ["timer", "round_" + round, "stage_" + stage].join("/");
			if(!Globals.Sim.isImpersonation){
				F.API.Data.saveAs(key, "time=" + timestamp + "&formattedTime=" + formattedTime);
			}
		};

		if(timestamp){
			save(timestamp);
		}
		else{
			$.getJSON("include/timer.txt", function(data){
				save(data.serverTime);
			});
		}
	},
	//Save to data api; mostly intermediate decisions while switching tabs
	saveDecisions: function(obj, callback){
		var round = Sim.Round.getCurrent();

		//Simulate workaround no:gazillion+1 , it doesn't like numbers as keys. Who does
		var key = "role_" + Globals.User.departmentID + "/round_" + round;

		//TODO: UGLY simulate hack. It doesn't like commas....of course
		var newobj = {};
		var val = F.makeObject(obj, {encode: false});
		for(var prop in val){
			var newkey = prop.replace(",", "||");
			newobj[newkey] = val[prop];
		}

		//Format when you tab out
		var options = {};
		if(F.isElement(obj) && obj.type.toLowerCase() == "text"){
			var varname = obj.name.replace("D_", "");
			var target = "include/getFormattedVal.txt?varname=" + varname;
			options = {target : target};
			var oldcb = callback;
			callback = function(response){
				response = $.trim(response);
				if(response !== "") $(obj).val(response);
				(oldcb || $.noop)();
			};
		}
//

		F.API.Data.saveAs(key, newobj, callback, options);
	},
	setDecisions: function(values, callback, options){
		var qs = [].concat(values);
		F.API.Run.saveValues(qs, callback, options);
	},
	setDecisionsForAdvance: function(values, callback, options){
		options = $.extend({},options,{target: "include/timer.txt"});

		HAS_DIRTY_DECISIONS = false;

		var qs = [].concat(values);
		var advCheck = function(data){
			WSim.simStateCheck($.parseJSON(data));
			(callback || $.noop)();
		};
		F.API.Run.saveValues(qs, advCheck, options);
	},
	decisions: {
		//Block user out of rest of sim and stick him on decisions page;
		force: function(){
			Globals.Sim.timeout = true;
			UI.navbar.close();
			UI.toolbar.close();
			nav.goToPage("usr_decisions");
		},
		unforce: function(){
			Globals.Sim.timeout = false;
			UI.navbar.open();
			UI.toolbar.open();
		},
		areAllValid: function(){
			if($('.flagged').length > 0) return false;
			else return true;
		},
		flagInvalid: function(input,message){
			if($(input).data('flagged') == 'true'){
				this.removeFlagInvalid(input);
			}
			$(input)
				.data('flagged','true')
				.parent()
					.addClass('flagged')
					.end()
				.after('<p class="inputWarning">'+message+'</p>');
		},
		removeFlagInvalid: function(input){
			$(input)
				.parent()
					.removeClass('flagged')
					.end()
				.removeData('flagged')
				.next('.inputWarning')
					.remove();
		},
		validate: function(input,type,min,max,callback,message, negativeMessage){
			min = parseFloat(min);
			max = parseFloat(max);
			var value = $(input).val();

			value = value.replace("$","");
			value = value.replace(" ","");
			value = value.replace(/,/g,"");

			if(type && type === "int"){
				if(isNaN(value) || value === ""){
					if(message && message !== ""){
						Sim.decisions.flagInvalid(input,message);
					}else{
						Sim.decisions.flagInvalid(input,'This field must contain a number!');
					}

					return false;
				}
				else{
					if((min || min === 0) && parseFloat(value) < min){
						if(message && message !==""){
							var mess = (negativeMessage) ? negativeMessage : message;
							Sim.decisions.flagInvalid(input,mess);
						}else{
							Sim.decisions.flagInvalid(input,'This field must contain a number greater than or equal to '+min+'!');
						}
						return false;
					}
					else if((max || max === 0) && parseFloat(value) > max){
						if(message && message !== ""){
							Sim.decisions.flagInvalid(input,message);
						}else{
							Sim.decisions.flagInvalid(input,'This field must contain a number lower than or equal to '+max+'!');
						}
						return false;
					}
					else if($(input).data('flagged') == 'true'){
						Sim.decisions.removeFlagInvalid(input);
					}

				}
			}

			Sim.saveDecisions(input,callback);
			Sim.decisions.departmentValidation();
		},
		departmentValidation: function(){
			switch(Globals.User.departmentID){
				case 1:
					break;
				case 2:
					try{
						var totalAssignedBudget = 0;
						var input = jQuery('input[name="totalAvailableBudget"]');
						var totalAvailableBudget = parseFloat(input.val());
						$('.ongoingDecisions input.budget').each(function(){
							var value = $(this).attr('value');
							value = value.replace("$","");
							value = value.replace(" ","");
							value = value.replace(/,/g,"");
							value = parseFloat(value);
							if(value || value === 0)
								totalAssignedBudget+=value;
						});
						if(totalAssignedBudget > totalAvailableBudget)
						{
							Sim.decisions.flagInvalid(input,'You have exceeded your Marketing Spending spending limit of $' + totalAvailableBudget + 'M');
						}
						else Sim.decisions.removeFlagInvalid(input);
					}
					catch(e){}
					break;
				case 3:
					try{
						var totalAssignedBudget = 0;
						var input = jQuery('input[name="totalAvailableBudget"]');
						var totalAvailableBudget = parseFloat(input.val());
						$('.ongoingDecisions input.budget').each(function(){
							var value = $(this).attr('value');
							value = value.replace("$","");
							value = value.replace(" ","");
							value = value.replace(/,/g,"");
							value = parseFloat(value);
							if(value || value == 0)
								totalAssignedBudget+=value;
						});
						if(totalAssignedBudget > totalAvailableBudget)
						{
							Sim.decisions.flagInvalid(input,'You have exceeded your Process Improvement spending limit of $' + totalAvailableBudget + 'M');
						}
						else Sim.decisions.removeFlagInvalid(input);
					}
					catch(e){}
					break;
				case 4:
					try{
						var totalAssignedBudget = 0;
						var input = jQuery('input[name="totalAvailableBudget"]');
						var totalAvailableBudget = parseFloat(input.val());
						$('input.incentiveBudget').each(function(){
							var value = $(this).attr('value');
							value = value.replace("$","");
							value = value.replace(" ","");
							value = value.replace(/,/g,"");
							value = parseFloat(value);
							if(value || value == 0)
								totalAssignedBudget+=value;
						});
						jQuery('#totalIncentChecked').text(Util.formatNumber(totalAssignedBudget,'$#,##0'));
						if(totalAssignedBudget > totalAvailableBudget)
						{
							Sim.decisions.flagInvalid(input,'You have exceeded your spending limit!');
						}
						else Sim.decisions.removeFlagInvalid(input);
					}
					catch(e){}
					break;
				case 5:
					try{
						var totalAssignedBudget = 0;
						var input = jQuery('input[name="totalAvailableBudget"]');
						var totalAvailableBudget = parseFloat(input.val());
						$('.ongoingDecisions input.budget').each(function(){
							var value = $(this).attr('value');
							value = value.replace("$","");
							value = value.replace(" ","");
							value = value.replace(/,/g,"");
							value = parseFloat(value);
							if(value || value == 0)
								totalAssignedBudget+=value;
						});
						if(totalAssignedBudget > totalAvailableBudget)
						{
							Sim.decisions.flagInvalid(input,'You have exceeded your spending limit of $' + totalAvailableBudget + 'M');
						}
						else Sim.decisions.removeFlagInvalid(input);
					}
					catch(e){}
					break;
				case 6:
					break;
				default:
					return false;
			}
		}
	},

	//Start new game;
	initialize: function(){
		// Sim.saveTimestamp();//Initialize timestamp; 2013: no longer applicable since Lab Leader sets it
		nav.goToPage("usr_dashboard");
	}
};

var UI = {
	investorMsg: {
		show: function(){
			$('#investorMsg').load("htm/news/investor.htm");
			$('#investorMsg').dialog({autoOpen: true, bgiframe: true,
			width: 860, height: 590, modal: true, closeOnEscape: false,
			draggable: false, dialogClass:'yellow', overlay: {opacity: '0.5', backgroundColor: '#000000'}, buttons : {
				'Close this message': function(){
					$(this).dialog('close');
				}
			}, resizable: false, title: 'News Flash!'});
		}
	},
	dialog: {
		init: function(){
			$('#confirm-window').dialog({autoOpen: false, bgiframe: true, width: 350, height: 250,
				modal: true, closeOnEscape: false, draggable: false,
				dialogClass:'blue', overlay: {opacity: '0.5', backgroundColor: '#000000'}, resizable: false, title: ''});
		},
		show: function(css_class){
			css_class = css_class || "blue";
			$('.ui-dialog').attr('class','ui-dialog ' + css_class);
			$('#confirm-window').dialog('open');
		},
		hide: function(){
			$('#confirm-window').dialog('close');
		},
		setContentTo: function(title,message){

			$('#confirm-window')
				.html("<p>"+message+"</p> <p> Waiting for the following players' decisions <span id='unfinished'>" +
								Globals.Sim.unfinished + "</span> </p>")
				.siblings()
				.find('span')
					.html('<span>'+title+'</span>');
		},
		setContent: function(mySwitch){
			//Note: CEO nomination popup isn't here, check usr_decisions_1_6
				var title, message;
				switch(mySwitch){
					case 'mismatch':
						message = 'One or more of the selections does not match the rest. Discuss with your team and make a consensus decision.';
						title = 'Conflict detected';
						break;
					case 'collision':
						message = 'There is a conflict detected in one or more role assignments.<br /><br />Please verify your role in the Settings Panel, coordinate with your peers, and select a new one if necessary before making any decisions.';
						title = 'Conflict detected';
						break;
					case 'validation error':
						message = 'Please correct the highlighted fields.';
						title = 'Cannot submit decisions';
						break;
					case 'incomplete':
						message = 'You have unanswered questions.';
						title = 'Cannot submit decisions';
						break;
					case 'points':
						message = 'You must distribute all points between your teammates.';
						title = 'Cannot submit decisions';
						break;
					case 'loading':
						message = 'Your answers have been recorded. Please wait a moment...';
						title = 'Loading...';
						break;
					default:
						message = "Waiting for the following players' decisions to advance the simulation: <span id='unfinished'>" +
								Globals.Sim.unfinished + "</span>" +
								"<br/><br/>You may continue to wait, or you can cancel and revise your decisions.";
						title = "Waiting for Players...";
						break;
				}

			$('#confirm-window')
				.html('<p>'+message+'</p>')
				.siblings()
					.find('span')
						.html('<span>'+title+'</span>');
		},
		setButtons: function(args){
			var advanceRound = function(){
				// $(this).dialog('close');
				dbug.advanceAll();
			};
			var closeDialog = function(){
				Sim.undoReadyToAdvance();
				$(this).dialog('close');
			};

			var buttons = {};
			for(var i=0;i<args.length;i++){
				var mySwitch = args[i];
				switch(mySwitch){
					case 'advance':
						if(Globals.Sim.debug) buttons['(debug) Advance Round'] = advanceRound;
						break;
					case 'ok':
					case 'Ok':
					case 'OK':
						buttons['Ok'] = closeDialog;
						break;
					case 'revise':
						buttons['Revise Decisions'] = closeDialog;
						break;
				}
			}

			$('#confirm-window').data("buttons.dialog", buttons);
		}
	},
	navbar: {
		open: function(){
			$('#navigation')
				.removeClass('closed')
				.addClass('open')
				.find(".default")
					.removeClass('default')
					.end()
				.find("li.extra")
					.hide();
			if(Globals.User.departmentID){
				$("#navigation li.tabRole" + Globals.User.departmentID).show();
			}
		},
		close: function(){
			$('#navigation')
				.removeClass('open')
				.addClass('closed');
		}
	},
	toolbar: {
		open: function(){
			$('#tool_credits, #tool_sim, #tool_settings, #tool_chat, #tool_survey1, #tool_survey2, #tool_survey3, #tool_survey4')
				.removeClass('closed')
				.addClass('open');
			$('#company_logo, #teamInfo, #currentYear').show();
		},

		close: function(){
			$('#tool_credits, #tool_sim, #tool_settings, #tool_chat, #tool_survey1, #tool_survey2, #tool_survey3, #tool_survey4')
				.removeClass('open')
				.addClass('closed');
		}
	},
	dashboard: {
		reset: function(){
			UI.dashboard.setCompanyName("");
			UI.dashboard.setYear(2018);
			UI.dashboard.setRound(1);
			UI.dashboard.setLogo(0);
			UI.dashboard.setPlayerRole("");
		},
		setCompanyName: function(newName){
			$('#teamInfo p').html(newName);
		},
		setYear: function(year){
			$('#currentYear p.year').html(year);
		},
		setRound: function(round){
			$('#currentYear p.round').html('Round '+round);
		},
		setLogo: function(logoId){
			$('#mainMast img').attr('src','images/logo_'+logoId+'_big.gif');
		},
		setPlayerRole: function(role){
			if(role !== "") $('#teamInfo .role').html(", "+role);
			else $('#teamInfo .role').html("");
		},
		update: function(round){
			round || (round = Sim.Round.getCurrent());
			UI.dashboard.setYear(round + 2017);
			UI.dashboard.setRound(round);
		}
	},
	toolTip: function(){
        $('.tooltip').hover(function(){
            var offsetVal = $(this).offset();
            var toolTipBlockHeight = $(this).height();
            var desc = $(this).attr('rel');
            $('body').prepend('<div class="character-desc' + this.id + '">' + desc + '</div>');
            $('.character-desc' + this.id).css({
                                                "background":"#FEFFBF",
                                                "position": "absolute",
                                                "top": parseInt(offsetVal.top, 10) + toolTipBlockHeight + 15 + "px",
                                                "left": offsetVal.left,
                                                "border":"1px dashed #999999",
                                                "padding":"3px 6px",
                                                "z-index": "999"
                                          });

        }, function(){
            $('.character-desc' + this.id).remove();
        });
    }
};



Sim.Company ={
	setName: function(nameElem){
		var compName = nameElem.value.replace(/"/g, "'");
		var qs = "{name:'" + compName + "'}";

		F.API.Data.saveAs('company',qs,function(){
			UI.dashboard.setCompanyName(compName);
		});
	},
	setLogo: function(logoElem){
		F.API.Data.saveAs('company',logoElem,function(){
			UI.dashboard.setLogo(logoElem.value);
		});
	},
	setUserPosition: function(positionElem){
		F.API.Run.saveValues(positionElem, function(){
			var positionLabel = $(positionElem).children(":selected").text();
			Globals.User.departmentID = parseInt(positionElem.value, 10);
			UI.dashboard.setPlayerRole(positionLabel);
		});
	}
};


// Overrides this function for the player, as the UI changes slightly as you navigate
nav.changePageUI = function(pageName){
	if ($('#navigation a[href="htm/' + pageName + '.htm"]').length !== 0)
	{
		var $tab = $('a[href="htm/' + pageName + '.htm"]').parent();
		$('#navigation li').removeClass('selected');
		$tab.addClass('selected')
			.parent()
				.addClass('open');
		$('.tabs').removeClass('open');
		$('.character-desc').remove();
	}

	switch(pageName){
		case 'usr_settings':
			UI.navbar.close();
			break;
		case 'usr_start':
		case 'usr_waiting_room':
		case 'usr_point_allocation':
		case 'usr_survey_360':
		case 'usr_survey_team':
		case 'usr_survey_answered':
			UI.navbar.close();
			UI.toolbar.close();
			break;
		case 'usr_decisions':
			if(Globals.Sim.timeout){
				UI.navbar.close();
				UI.toolbar.close();
			}
			else {
				UI.navbar.open();
				UI.toolbar.open();
			}
			break;
		default:
			UI.navbar.open();
			UI.toolbar.open();
			break;
	}
	$('#loadingMsg').hide();
	UI.toolTip();
};

nav.changePageHandler = function(page)
{
	if(Globals.Sim.timeout){
		nav.loadDiv('usr_decisions');
	}
	else if(!Globals.Sim.isOpen){
		nav.loadDiv('usr_start');
	}
	else {
		nav.loadDiv(page);
	}
};

YAHOO.util.Event.onDOMReady(function()
{
	var bookmarkedState = History.getBookmarkedState(nav.module);
	var startPage = 'usr_start';

	var initialState = bookmarkedState || startPage;

	History.register(nav.module, initialState, nav.changePageHandler);
	History.onReady(function(){ nav.changePageHandler(History.getCurrentState(nav.module)); });
	History.initialize('yui-history-field', 'yui-history-iframe');
	UI.dialog.init();
});