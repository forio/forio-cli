var pieChart = function()
{
	return{
		playerNumber: 0,
		totalPointsAwarded: 0,
		
		value: {
			input1: 0,
			input2: 0,
			input3: 0,
			input4: 0,
			input5: 0,
			input6: 0
		},
		
		initialized: false,
		
		name: {
			input1: "",
			input2: "",
			input3: "",
			input4: "",
			input5: "",
			input6: ""
		},
		
		colors: {
			player1: "#035dcd",
			player2: "#54A0FC",
			player3: "#d4e7fe",
			player4: "#686868",
			player5: "#a8a8a8",
			player6: "#e9e9e9"
		},
		
		reDraw: function(){
			var xmlValues = new String;
			var totalPoints = pointValidation.totalPointsAvailable;
			
			for (var i = 1; i <= pieChart.playerNumber; i++){
				totalPoints = totalPoints - parseInt(pieChart.value["input"+i],10);
				if(parseInt(pieChart.value["input"+i],10) != 0)
					xmlValues = xmlValues+"<set label='"+pieChart.name["input"+i]+"' value='"+pieChart.value["input"+i]+"' label='' color='"+pieChart.colors["player"+i]+"'/>";
			}
				
			if(totalPoints > 0)
				xmlValues = xmlValues + "<set label='Remaining' value='"+totalPoints+"' label='' color='#ffffff'/>";

			if (this.totalPointsAwarded >= 0 && this.totalPointsAwarded <= 120 && this.initialized){
				chart.setDataXML("<chart showPercentageValues='1' chartLeftMargin='0' chartBottomMargin='40' chartRightMargin='20' chartTopMargin='40' pieSliceDepth='10' use3DLighting='0' pieRadius='100' enableSmartLabels='0' labelDistance='10' baseFontSize='10' bgColor='#FFFFFF' showLabels='1' showPercentValues='0' showValues='0'>"+xmlValues+"</chart>");
			}
			this.initialized = true;
			
		}
	}
}();

var pointValidation = function()
{
	return {
		totalPointsAwarded: 0,
		totalPointsAvailable: 0,
		
		init: function(){
			this.reCalc();
			this.blurHandler();
			this.submitValidate();
		},
		
		blurHandler: function(){
			$('#points input:not(":submit, :button")').blur(function(){
				pointValidation.reCalc();
			})
		},
		
		reCalc: function(){	
			try {
				var that = this;
			
				//This block here adds up all the inputs and figures out how many points are available and inserts value in a div.
				that.totalPointsAwarded = 0;
				var i = 1;
				$('#points input:not(":submit, :button, :hidden")').each(function(){ 
					var value = this.value;
					value = value.replace("$","");
					value = value.replace(" ","");
					value = value.replace(/,/g,"");
					if(isNaN(value) || value == ""){
						value = 0;
					}
					that.totalPointsAwarded += parseInt(value,10);
					that.percentage($(this).attr('id'),value);
					pieChart.value["input"+i] = value;
					pieChart.name["input"+i] = $(this).attr('title');
					i++;
				});
				
				var rem = that.totalPointsAvailable - that.totalPointsAwarded;
				var award = that.totalPointsAwarded;
				(rem <= 0) ? (rem = 0) : rem;
				$('#pointsRemaining span').html(""+rem);
				$('#pointsAwarded span').html(""+award);
							
				//This sends the input value to the updateChart function to redraw the chart
				pieChart.totalPointsAwarded = that.totalPointsAwarded;
				pieChart.reDraw();
			}
			catch(e){
				return false;
			}
		},
		
		submitValidate: function(callback){
			var that = pointValidation;
			$('.pointSubmit').click(function(){
				if(that.totalPointsAwarded != that.totalPointsAvailable){
					$('#confirm-window').data("buttons.dialog", {'Ok': UI.dialog.hide } );
					UI.dialog.setContent('points');
					UI.dialog.show('yellow');
				}
				else{
					if(callback) callback();
				}
			})
		},
		
		percentage: function(el,value){
			el = el.substring(5,6);
			value = parseInt((value/this.totalPointsAvailable)*100,10);
			$('#percentage'+el).html(value+'%')
		}
	}
}();