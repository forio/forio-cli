var WSim = function(){
	var TIMER_INTERVAL = 5000;

	var simStateCheck = function(data){
		// Update the dashboard
		UI.dashboard.setCompanyName(data.companyName);
		UI.dashboard.setLogo(data.companyLogo);

		var currRound  = Sim.Round.getCurrent();
		var simRound = parseInt(data.round, 10);
		var isRoundOver = (data.roundOver) || (currRound < simRound); //If you're seeing the roundover for the first time, or someone stepped inbetween your polls

		var currStage = Sim.Stage.getCurrent();
		var simStage = data.decisionsStage;
		var isStageOver = (simStage !== 0) && (currStage < simStage);

		var uniqueEventKey = [simRound, simStage, data.roundOver, data.investor, data.allVotesIn];
		var timestamp = data.serverTime;

		//console.log("simstagecheck", isStageOver, currStage, simStage);

		var wrongConsensusCnt = 0;

		if(data.gameOver){
			F.Events.fireOnce(WSim.Events.gameOver, "", [simRound]);
		}

		if(data.dayOver){
			F.Events.fireOnce(WSim.Events.dayOver, {round:simRound}, [simRound]);
		}
		else if(isRoundOver){
			Globals.Sim.unfinished = data.unfinished;
			F.Events.fireOnce(WSim.Events.roundOver, {round: simRound, stage: simStage, time: timestamp}, uniqueEventKey);
		}
		else if(isStageOver){
			//console.log("isStageOver", {round: simRound, stage: simStage, time: timestamp});
			F.Events.fireOnce(WSim.Events.stageOver, {round: simRound, stage: simStage, time: timestamp}, uniqueEventKey);
		}
		else if(data.allVotesIn){
			//console.log("allVotesIn", {round:simRound, consensus: data.consensus, stage: simStage});

			F.Events.fireOnce(WSim.Events.allVotesIn, {round:simRound, consensus: data.consensus, stage: simStage},
				[simRound, simStage, data.consensus]);
		}
		else if(parseInt(data.timeLeft, 10) === 0){ //Time out for this round
			F.Events.fireOnce(WSim.Events.timeOut, simRound , uniqueEventKey);
		}
		//Investor message specific to round 9
		if(data.readyToInvest){
			F.Events.fireOnce(WSim.Events.readyToInvest, "", uniqueEventKey);
		}

		//Timer events
		if (data.timeLeft !== data.totalTime) {
			F.Events.fire(WSim.Events.timeChanged, [data.timeLeft, data.totalTime]);
		}

		if(data.unfinished !== Globals.Sim.unfinished){
			Globals.Sim.unfinished = data.unfinished;
			F.Events.fire(WSim.Events.userSubmitted, data.unfinished);
		}
	};
	var pc = new PollingConnection("include/timer.txt", {}, {interval: TIMER_INTERVAL, onPulse: simStateCheck}, {
		onError:function(errorMessage, errorThrown){
			if(errorThrown){
				if(window.console && window.console.log){
					window.console.log(errorThrown, errorMessage);
					em += " .Logged to console.";
				}
			}
		}

	});

	return{
		//In case you want to call this manually with the data.
		simStateCheck: function(data){
			simStateCheck(data);
		},
		init: function(){
			if(!Globals.Sim.isImpersonation){
				pc.init();
				//For beginning of new days set it when someone first logs in except for day 1
				if(!Globals.Sim.isRoundTimeSet && Sim.Round.getCurrent() != 1 && Globals.Sim.isOpen){
					if(!Globals.Sim.isFirstRoundofTheDay){
						Sim.saveTimestamp(); //Lab leader sets it for first round
					}
				}
			}
		}()
	};
}();

WSim.Events ={
	//Server time changed
	timeChanged:  new YAHOO.util.CustomEvent("timechanged", this, true, YAHOO.util.CustomEvent.FLAT),
	//Round time over
	timeOut:   new YAHOO.util.CustomEvent("timeout", this, true, YAHOO.util.CustomEvent.FLAT),

	//Game over
	gameOver: new YAHOO.util.CustomEvent("gameOver", this, true, YAHOO.util.CustomEvent.FLAT),
	//Day over
	dayOver: new YAHOO.util.CustomEvent("dayOver", this, true, YAHOO.util.CustomEvent.FLAT),
	//Round over (before timeout)
	roundOver: new YAHOO.util.CustomEvent("roundOver", this, true, YAHOO.util.CustomEvent.FLAT),
	//Stage over (for multistage rounds)
	stageOver: new YAHOO.util.CustomEvent("stageOver", this, true, YAHOO.util.CustomEvent.FLAT),

	userSubmitted: new YAHOO.util.CustomEvent("userSubmitted", this, true, YAHOO.util.CustomEvent.FLAT),
	// Consensus reached
	allVotesIn:  new YAHOO.util.CustomEvent("allVotesIn", this, true, YAHOO.util.CustomEvent.FLAT),
	//Time set by admin for round is triggered
	readyToInvest:  new YAHOO.util.CustomEvent("readyToInvest", this, true, YAHOO.util.CustomEvent.FLAT),
	companyInfoChanged:  new YAHOO.util.CustomEvent("companyChanged", this, true, YAHOO.util.CustomEvent.FLAT),

	timerStartedEvent: new YAHOO.util.CustomEvent("timerStarted", this, true, YAHOO.util.CustomEvent.FLAT)
};

